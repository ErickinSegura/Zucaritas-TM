﻿namespace AWAQApi
{
    public class tutorial
    {
        public int ID_User { get; set; }
        public int Tutorial { get; set; }
    }
}
