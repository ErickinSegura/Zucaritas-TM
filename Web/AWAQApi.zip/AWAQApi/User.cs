﻿namespace AWAQApi
{
    public class User
    {
        public int ID_User { get; set; }
        public int Tutorial { get; set; }
    }
}
