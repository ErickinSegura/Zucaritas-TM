﻿namespace AWAQApi
{
    public class score
    {
        public int id_user { get; set; }
        public int puntaje { get; set; }
        public int muestreo { get; set; }

    }
}
